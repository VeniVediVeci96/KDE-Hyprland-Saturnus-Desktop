#!/usr/bin/env bash
set -e
echo "Applying Kvantum theme..."
mkdir -p ~/.config/Kvantum
cp -r kvantum/* ~/.config/Kvantum/
echo "Applying GTK theme..."
mkdir -p ~/.config/gtk-3.0
cp gtk-3.0/settings.ini ~/.config/gtk-3.0/settings.ini
echo "Done. Open Kvantum Manager to select 'SweetOrangeKvantum'."